/*
 * Copyright 2010-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license
 * that can be found in the LICENSE file.
 */

package kotlin.reflect

/**
 * Represents an entity which may contain declarations of any other entities,
 * such as a class or a package.
 */
public interface KDeclarationContainer